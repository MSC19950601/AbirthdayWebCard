## Introduction
My Valentine's Day gift to the sweetheart.

1. ~~[http://netcan.zzilcc.com](http://netcan.zzilcc.com)~~
2. [http://netcan.github.io/MyZzilcc](http://netcan.github.io/MyZzilcc)

## TODO
1. ~~页面增加搜索栏，方便做浏览器首页。(Page add the search bar, for setting browser home page.)~~
2. ~~增加名言警句(add quotes)~~
3. ~~增加小型记事本(add notebooks)~~
4. 增加音乐盒(add musicbox)
5. ~~编辑器增强(Improve notebooks editor)~~

## License
MIT
